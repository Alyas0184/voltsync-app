/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { InventoryItem, Labourer, WorkTask, UserProfile, AppSettings, SaleTransaction, PaymentStatus, PaymentMethod, Customer, SiteSettlement } from "../types";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "./ui/card";
import { Badge } from "./ui/badge";
import { 
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip 
} from "recharts";
import { Activity, Package, Users, AlertTriangle, ShoppingCart, Settings as SettingsIcon, User, CreditCard, Banknote, History, Edit2, CheckCircle2, Bolt, Printer, ExternalLink } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { Label } from "./ui/label";
import { Switch } from "./ui/switch";
import { ScrollArea } from "./ui/scroll-area";
import { toast } from "sonner";

interface DashboardProps {
  inventory: InventoryItem[];
  setInventory: React.Dispatch<React.SetStateAction<InventoryItem[]>>;
  labourers: Labourer[];
  setLabourers: React.Dispatch<React.SetStateAction<Labourer[]>>;
  tasks: WorkTask[];
  setTasks: React.Dispatch<React.SetStateAction<WorkTask[]>>;
  user: UserProfile;
  setUser: React.Dispatch<React.SetStateAction<UserProfile>>;
  appSettings: AppSettings;
  setAppSettings: React.Dispatch<React.SetStateAction<AppSettings>>;
  transactions: SaleTransaction[];
  setTransactions: React.Dispatch<React.SetStateAction<SaleTransaction[]>>;
  customers: Customer[];
  setCustomers: React.Dispatch<React.SetStateAction<Customer[]>>;
  siteSettlements: SiteSettlement[];
  setSiteSettlements: React.Dispatch<React.SetStateAction<SiteSettlement[]>>;
}

const COLORS = ['#FFFFFF', '#60A5FA', '#334155', '#1E293B'];

export function Dashboard({ 
  inventory, 
  setInventory, 
  labourers, 
  setLabourers,
  tasks,
  setTasks,
  user,
  setUser,
  appSettings,
  setAppSettings,
  transactions,
  setTransactions,
  customers,
  setCustomers,
  siteSettlements,
  setSiteSettlements
}: DashboardProps) {
  const [isSellOpen, setIsSellOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isCustomersOpen, setIsCustomersOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isInventoryMgmtOpen, setIsInventoryMgmtOpen] = useState(false);
  const [isAlertsMgmtOpen, setIsAlertsMgmtOpen] = useState(false);
  const [isWorkforceMgmtOpen, setIsWorkforceMgmtOpen] = useState(false);
  const [isOrdersMgmtOpen, setIsOrdersMgmtOpen] = useState(false);
  const [isTasksMgmtOpen, setIsTasksMgmtOpen] = useState(false);
  const [isLabourerEditOpen, setIsLabourerEditOpen] = useState(false);
  const [isSiteSettlementOpen, setIsSiteSettlementOpen] = useState(false);
  const [isSettlementLedgerOpen, setIsSettlementLedgerOpen] = useState(false);
  const [isInvoiceOpen, setIsInvoiceOpen] = useState(false);
  const [lastTransaction, setLastTransaction] = useState<SaleTransaction | null>(null);
  const [editingLabourer, setEditingLabourer] = useState<Labourer | null>(null);

  const [selectedSite, setSelectedSite] = useState<string>("");
  const [siteValue, setSiteValue] = useState<number>(0);
  const [isManualSettlement, setIsManualSettlement] = useState<boolean>(false);
  const [manualSiteName, setManualSiteName] = useState<string>("");
  const [manualSettledCost, setManualSettledCost] = useState<number>(0);

  const [tempUser, setTempUser] = useState(user);
  const [manualSale, setManualSale] = useState<{
    itemId: string;
    customName: string;
    quantity: number;
    unitPrice: number;
    isPaid: boolean;
    paymentMethod: PaymentMethod;
    paidAmount: number;
    customerId: string;
    newCustomerName: string;
  }>({
    itemId: "",
    customName: "",
    quantity: 1,
    unitPrice: 0,
    isPaid: true,
    paymentMethod: 'Cash',
    paidAmount: 0,
    customerId: "walk-in",
    newCustomerName: "",
  });

  const lowStockCount = inventory.filter(i => i.quantity <= i.minStock).length;
  const activeLabourCount = labourers.filter(l => l.status === 'On Assignment').length;
  const openOrdersCount = transactions.filter(t => t.paymentStatus !== 'Paid').length;
  const activeTasksCount = tasks.filter(t => t.status !== 'Completed').length;

  const handleUpdateSettings = () => {
    setUser(tempUser);
    toast.success("Profile & Core Parameters Synchronized");
    setIsSettingsOpen(false);
  };

  const handleUpdateLabourer = () => {
    if (editingLabourer) {
      setLabourers(prev => prev.map(l => l.id === editingLabourer.id ? editingLabourer : l));
      setIsLabourerEditOpen(false);
      setEditingLabourer(null);
      toast.success("Workforce Logistics Synchronized");
    }
  };

  const openSettings = () => {
    setTempUser(user);
    setIsSettingsOpen(true);
  };

  const handleExecuteSale = () => {
    const qty = Number(manualSale.quantity) || 0;
    const rate = Number(manualSale.unitPrice) || 0;
    const totalAmount = qty * rate;
    const paid = manualSale.isPaid ? totalAmount : Number(manualSale.paidAmount) || 0;
    
    let currentCustomerId = manualSale.customerId;
    let currentCustomerName = "Walk-in Customer";

    // Handle Customer Identity
    if (manualSale.customerId === "new" && manualSale.newCustomerName.trim()) {
      const newId = `CST-${Date.now()}`;
      const newCust: Customer = {
        id: newId,
        name: manualSale.newCustomerName.trim(),
        totalSpent: 0,
        lastVisit: new Date().toISOString()
      };
      setCustomers(prev => [...prev, newCust]);
      currentCustomerId = newId;
      currentCustomerName = newCust.name;
    } else if (manualSale.customerId !== "walk-in") {
      const found = customers.find(c => c.id === manualSale.customerId);
      if (found) currentCustomerName = found.name;
    }

    if ((!manualSale.itemId && !manualSale.customName) || qty <= 0) {
      toast.error("Protocol Error: Designation or Quantity missing.");
      return;
    }

    const updatedInventory = [...inventory];
    let finalItemName = manualSale.customName;
    
    if (manualSale.itemId) {
      const idx = updatedInventory.findIndex(i => i.id === manualSale.itemId);
      if (idx !== -1) {
        const item = updatedInventory[idx];
        finalItemName = item.name;
        if (item.quantity < qty) {
          toast.error("Insufficient stock volume.");
          return;
        }
        updatedInventory[idx] = {
          ...item,
          quantity: item.quantity - qty,
        };
      }
    }

    // Record Transaction
    const newTransaction: SaleTransaction = {
      id: `TXN-${Date.now()}`,
      timestamp: new Date().toISOString(),
      itemId: manualSale.itemId || undefined,
      itemName: finalItemName,
      quantity: qty,
      totalAmount: totalAmount,
      paidAmount: paid,
      paymentStatus: paid >= totalAmount ? 'Paid' : (paid > 0 ? 'Partial' : 'Unpaid'),
      paymentMethod: manualSale.isPaid ? manualSale.paymentMethod : 'N/A',
      customerName: currentCustomerName
    };

    // Update Customer Metrics
    if (currentCustomerId !== "walk-in") {
      setCustomers(prev => prev.map(c => 
        c.id === currentCustomerId 
          ? { ...c, totalSpent: c.totalSpent + (manualSale.isPaid ? totalAmount : paid), lastVisit: new Date().toISOString() }
          : c
      ));
    }

    setTransactions([newTransaction, ...transactions]);
    setInventory(updatedInventory);
    setLastTransaction(newTransaction);
    setIsSellOpen(false);
    setIsInvoiceOpen(true);
    setManualSale({ 
      itemId: "", 
      customName: "", 
      quantity: 1, 
      unitPrice: 0, 
      isPaid: true, 
      paymentMethod: 'Cash', 
      paidAmount: 0,
      customerId: "walk-in",
      newCustomerName: ""
    });
    toast.success("Transaction Securely Committed");
  };

  const categoryData = inventory.reduce((acc: any[], item) => {
    const existing = acc.find(a => a.name === item.category);
    if (existing) {
      existing.value += item.quantity;
    } else {
      acc.push({ name: item.category, value: item.quantity });
    }
    return acc;
  }, []);

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <div className="flex justify-between items-center bg-white/[0.02] p-6 border border-white/5">
        <div>
          <h2 className="text-xl font-serif italic text-white underline decoration-accent-blue/30 underline-offset-8">Operations Command</h2>
          <p className="text-[10px] uppercase tracking-[0.2em] text-slate-500 mt-2">Real-time infrastructure monitoring</p>
        </div>

        <div className="flex gap-4">
          <Dialog open={isCustomersOpen} onOpenChange={setIsCustomersOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="rounded-none border-accent-blue/30 text-white text-[10px] uppercase tracking-widest h-10 hover:bg-white hover:text-black shadow-[0_0_15px_rgba(96,165,250,0.15)] bg-accent-blue/5">
                <Users className="w-3 h-3 mr-2" /> Client Sync
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-bg-primary border-white/10 text-white rounded-none sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle className="font-serif italic text-xl">Customer Registry</DialogTitle>
              </DialogHeader>
              <ScrollArea className="h-[400px] font-mono pr-4">
                {customers.length === 0 ? (
                  <div className="text-center py-20 text-slate-500 text-[10px] uppercase tracking-widest">Registry Empty: Walk-in traffic only</div>
                ) : (
                  <div className="space-y-4">
                    {customers.sort((a,b) => b.totalSpent - a.totalSpent).map(c => (
                      <div key={c.id} className="p-4 bg-white/5 border border-white/10 flex justify-between items-center">
                        <div>
                          <p className="text-[10px] text-white font-bold">{c.name}</p>
                          <p className="text-[8px] text-slate-500 uppercase tracking-tighter">Last Active: {new Date(c.lastVisit).toLocaleDateString()}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-accent-blue text-[10px] font-bold">{appSettings.currency}{c.totalSpent.toLocaleString()}</p>
                          <p className="text-[8px] text-slate-600 uppercase">Life Volume</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </DialogContent>
          </Dialog>

          <Dialog open={isHistoryOpen} onOpenChange={setIsHistoryOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="rounded-none border-accent-blue/30 text-white text-[10px] uppercase tracking-widest h-10 hover:bg-white hover:text-black shadow-[0_0_15px_rgba(96,165,250,0.15)] bg-accent-blue/5">
                <History className="w-3 h-3 mr-2" /> Log Book
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-bg-primary border-white/10 text-white rounded-none sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle className="font-serif italic text-xl">Sale Registry history</DialogTitle>
              </DialogHeader>
              <ScrollArea className="h-[400px] font-mono pr-4">
                {transactions.length === 0 ? (
                  <div className="text-center py-20 text-slate-500 text-[10px] uppercase tracking-widest">No transactions logged</div>
                ) : (
                  <div className="space-y-4">
                    {transactions.map(txn => (
                      <div key={txn.id} className="p-4 bg-white/5 border border-white/10 space-y-2">
                        <div className="flex justify-between items-start">
                          <div>
                            <p className="text-[10px] text-white font-bold">{txn.itemName}</p>
                            <p className="text-[8px] text-slate-500 uppercase tracking-tighter">{new Date(txn.timestamp).toLocaleString()}</p>
                          </div>
                          <Badge variant="outline" className={`text-[8px] rounded-none ${txn.paymentStatus === 'Paid' ? 'border-accent-blue text-accent-blue' : 'border-accent-amber text-accent-amber'}`}>
                            {txn.paymentStatus}
                          </Badge>
                        </div>
                        <div className="flex justify-between text-[10px]">
                          <span className="text-slate-500">QTY: {txn.quantity}</span>
                          <span className="text-white">Total: {appSettings.currency}{txn.totalAmount.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-[9px] border-t border-white/5 pt-2">
                          <span className="text-slate-500">VIA: {txn.paymentMethod}</span>
                          <span className="text-accent-blue font-bold">RECV: {appSettings.currency}{txn.paidAmount.toLocaleString()}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </DialogContent>
          </Dialog>

          <Dialog open={isSettingsOpen} onOpenChange={setIsSettingsOpen}>
            <DialogTrigger asChild>
              <Button onClick={openSettings} variant="outline" className="rounded-none border-accent-blue/30 text-white text-[10px] uppercase tracking-widest h-10 hover:bg-white hover:text-black shadow-[0_0_15px_rgba(96,165,250,0.15)] bg-accent-blue/5">
                <SettingsIcon className="w-3 h-3 mr-2" /> Global Config
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-bg-primary border-white/10 text-white rounded-none sm:max-w-[400px]">
              <DialogHeader>
                <DialogTitle className="font-serif italic text-xl">System Configuration</DialogTitle>
              </DialogHeader>
              <div className="grid gap-6 py-4 font-mono">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase text-slate-500">Personnel ID Path</label>
                    <div className="flex gap-2">
                      <div className="bg-white/5 border border-white/10 flex items-center justify-center p-2">
                        <User className="w-4 h-4 text-accent-blue" />
                      </div>
                      <Input 
                        value={tempUser.name}
                        onChange={e => setTempUser({...tempUser, name: e.target.value})}
                        className="bg-white/5 border-white/10 rounded-none h-10 text-xs"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase text-slate-500">Visual Protocol (Theme)</label>
                    <Select 
                      value={appSettings.theme} 
                      onValueChange={(val: any) => setAppSettings({ ...appSettings, theme: val })}
                    >
                      <SelectTrigger className="bg-white/5 border-white/10 rounded-none h-10 text-xs text-white uppercase tracking-tight">
                        <SelectValue placeholder="DEPLOY INTERFACE..." />
                      </SelectTrigger>
                      <SelectContent className="bg-bg-primary border-white/10 text-white rounded-none">
                        <SelectItem value="technical" className="text-[10px] uppercase focus:bg-white/5 font-mono">Standard Technical</SelectItem>
                        <SelectItem value="monochrome" className="text-[10px] uppercase focus:bg-white/5 font-mono">High Contrast (Mono)</SelectItem>
                        <SelectItem value="industrial" className="text-[10px] uppercase focus:bg-white/5 font-mono">Industrial Decay</SelectItem>
                        <SelectItem value="classic" className="text-[10px] uppercase focus:bg-white/5 font-mono">Legacy Mode</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] uppercase text-slate-500">Atmospheric Layer (Background)</label>
                    <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
                      {[
                        { id: 'default', color: '#0A0A0B', label: 'VOID' },
                        { id: 'golden', color: '#1a1600', label: 'GOLD' },
                        { id: 'black', color: '#000000', label: 'PURE' },
                        { id: 'white', color: '#f8f9fa', label: 'STARK' },
                        { id: 'chocolate', color: '#1b1210', label: 'DARK' },
                        { id: 'lightgreen', color: '#f0f9f0', label: 'MINT' },
                        { id: 'premiumgold', color: '#2a2408', label: 'ROYAL' }
                      ].map((bg) => (
                        <button
                          key={bg.id}
                          onClick={() => setAppSettings({ ...appSettings, background: bg.id as any })}
                          className={`group relative h-10 border transition-all ${appSettings.background === bg.id ? 'border-accent-blue scale-105' : 'border-white/10 hover:border-white/30'}`}
                          title={bg.label}
                        >
                          <div className="absolute inset-0.5" style={{ backgroundColor: bg.color }} />
                          {appSettings.background === bg.id && (
                            <div className="absolute inset-0 flex items-center justify-center">
                              <div className="w-1 h-1 bg-accent-blue rounded-full shadow-[0_0_8px_#60A5FA]" />
                            </div>
                          )}
                          <span className="absolute -bottom-4 left-0 right-0 text-[6px] text-center text-slate-600 uppercase font-mono opacity-0 group-hover:opacity-100 transition-opacity">
                            {bg.label}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase text-slate-500">Signal Protocols</label>
                    <div className="flex flex-col gap-2 p-3 bg-white/[0.03] border border-white/10">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] uppercase font-mono text-slate-300">Automated Signal Relays</span>
                        <input 
                          type="checkbox" 
                          checked={appSettings.notifications} 
                          onChange={e => setAppSettings({...appSettings, notifications: e.target.checked})}
                          className="accent-accent-blue"
                        />
                      </div>
                      <div className="flex items-center justify-between opacity-50 cursor-not-allowed">
                        <span className="text-[10px] uppercase font-mono text-slate-300">Email Alerts (Encrypted)</span>
                        <input type="checkbox" checked={true} disabled className="accent-accent-blue" />
                      </div>
                      <p className="text-[8px] uppercase font-mono text-slate-600 mt-1">Status: Low stock monitoring active via in-app terminal.</p>
                    </div>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button 
                  onClick={handleUpdateSettings}
                  className="w-full bg-accent-blue text-bg-primary hover:bg-white transition-colors rounded-none font-sans uppercase tracking-[0.2em] text-[10px] h-11"
                >
                  Synchronize State
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <Dialog open={isInvoiceOpen} onOpenChange={setIsInvoiceOpen}>
            <DialogContent className="bg-white text-black rounded-none p-0 max-w-[400px] border-none shadow-2xl">
              <div id="printable-bill" className="p-10 font-mono text-black bg-white">
                <div className="text-center border-b-2 border-black pb-6 mb-6">
                  <h2 className="text-2xl font-bold uppercase tracking-tighter">Business Invoice</h2>
                  <div className="flex justify-between items-end mt-4">
                    <div className="text-left">
                      <p className="text-[10px] font-bold text-slate-500 uppercase">Transaction ID</p>
                      <p className="text-[10px] font-bold">{lastTransaction?.id}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-[10px] font-bold text-slate-500 uppercase">Timestamp</p>
                      <p className="text-[10px]">{lastTransaction ? new Date(lastTransaction.timestamp).toLocaleString() : ''}</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex justify-between border-b border-black/10 pb-2">
                    <span className="text-[10px] font-bold uppercase text-slate-400">Client Identity</span>
                    <span className="text-[10px] font-bold uppercase">{lastTransaction?.customerName}</span>
                  </div>
                  <div className="flex justify-between border-b border-black/10 pb-2">
                    <span className="text-[10px] font-bold uppercase text-slate-400">Designation</span>
                    <span className="text-[10px] uppercase truncate ml-4 text-right">{lastTransaction?.itemName}</span>
                  </div>
                  <div className="flex justify-between border-b border-black/10 pb-2">
                    <span className="text-[10px] font-bold uppercase text-slate-400">Volume</span>
                    <span className="text-[10px]">{lastTransaction?.quantity} UNITS</span>
                  </div>
                  
                  <div className="mt-8 pt-4 border-t-2 border-black space-y-2">
                    <div className="flex justify-between items-baseline">
                      <span className="text-sm font-bold uppercase">Total Contract</span>
                      <span className="text-xl font-bold">{appSettings.currency}{lastTransaction?.totalAmount.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between items-center text-[10px] py-1 border-y border-black/5 italic">
                      <span className="text-slate-500">Amount Settled</span>
                      <span>{appSettings.currency}{lastTransaction?.paidAmount.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between items-center text-[10px] font-bold">
                      <span className="text-slate-500 font-normal">Balance Outstanding</span>
                      <span className={lastTransaction && lastTransaction.totalAmount - lastTransaction.paidAmount > 0 ? 'text-red-600' : 'text-slate-500'}>
                        {appSettings.currency}{lastTransaction ? (lastTransaction.totalAmount - lastTransaction.paidAmount).toLocaleString() : 0}
                      </span>
                    </div>
                  </div>

                  <div className="bg-slate-50 p-3 mt-4 border border-black/5">
                    <div className="flex justify-between items-center">
                      <span className="text-[8px] uppercase text-slate-400">Protocol</span>
                      <span className="text-[10px] font-bold uppercase">{lastTransaction?.paymentMethod} RELAY</span>
                    </div>
                  </div>
                </div>

                <div className="mt-12 pt-6 border-t border-dashed border-black/30 text-center">
                  <p className="text-[8px] uppercase tracking-widest font-bold">Thank you for your business</p>
                  <div className="mt-6 flex justify-center">
                    <div className="border-b border-black w-24 h-px opacity-20"></div>
                  </div>
                  <p className="text-[7px] uppercase mt-2 text-slate-400 italic">Electronic Authorization Validated</p>
                </div>
              </div>
              
              <div className="p-4 bg-slate-900 flex gap-2 no-print">
                <Button 
                  onClick={() => window.print()}
                  className="w-full bg-accent-blue text-bg-primary hover:bg-white rounded-none h-12 uppercase text-[10px] tracking-[0.2em] font-sans font-bold"
                >
                  <Printer className="w-3 h-3 mr-2" /> Commit to Print
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog open={isSiteSettlementOpen} onOpenChange={setIsSiteSettlementOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="rounded-none border-accent-blue/30 text-white text-[10px] uppercase tracking-widest h-10 hover:bg-white hover:text-black shadow-[0_0_15px_rgba(96,165,250,0.15)] bg-accent-blue/5">
                <Bolt className="w-3 h-3 mr-2" /> Site Settlement
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-bg-primary border-white/10 text-white rounded-none sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle className="font-serif italic text-xl">Fiscal Site Settlement</DialogTitle>
              </DialogHeader>
              <div className="grid gap-6 py-4 font-mono">
                <div className="flex items-center justify-between p-3 bg-white/5 border border-white/10 mb-2">
                  <div className="space-y-0.5">
                    <p className="text-[10px] uppercase text-white font-bold">Manual Entry Mode</p>
                    <p className="text-[8px] text-slate-500 uppercase tracking-tighter">Bypass workforce matrix data</p>
                  </div>
                  <Switch 
                    checked={isManualSettlement}
                    onCheckedChange={(val) => {
                      setIsManualSettlement(val);
                      setSelectedSite("");
                      setManualSiteName("");
                    }}
                  />
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase text-slate-500">Target Work Site</label>
                    {isManualSettlement ? (
                      <Input 
                        value={manualSiteName}
                        onChange={e => setManualSiteName(e.target.value.toUpperCase())}
                        placeholder="ENTER SITE NAME..."
                        className="bg-white/5 border-white/10 rounded-none h-10 text-xs"
                      />
                    ) : (
                      <Select value={selectedSite} onValueChange={setSelectedSite}>
                        <SelectTrigger className="bg-white/5 border-white/10 rounded-none h-10 text-xs">
                          <SelectValue placeholder="LOCATE SITE..." />
                        </SelectTrigger>
                        <SelectContent className="bg-bg-primary border-white/10 text-white rounded-none">
                          {Array.from(new Set(labourers.filter(l => l.workSite).map(l => l.workSite))).length === 0 ? (
                            <div className="p-4 text-center text-[10px] text-slate-500 italic uppercase">No sites designated in workforce matrix</div>
                          ) : (
                            Array.from(new Set(labourers.filter(l => l.workSite).map(l => l.workSite))).map(site => (
                              site && <SelectItem key={site} value={site} className="text-[10px] uppercase font-mono">{site}</SelectItem>
                            ))
                          )}
                        </SelectContent>
                      </Select>
                    )}
                  </div>

                  {(isManualSettlement || selectedSite) && (
                    <div className="space-y-4 animate-in fade-in slide-in-from-top-2 duration-500">
                      {!isManualSettlement && (
                        <div className="grid grid-cols-2 gap-px bg-white/5 border border-white/5">
                          <div className="bg-white/[0.02] p-4 text-center">
                            <p className="text-[8px] uppercase text-slate-500 tracking-widest mb-1">Total Labour Costs</p>
                            <p className="text-xl font-serif text-white">
                              {appSettings.currency}{labourers
                                .filter(l => l.workSite === selectedSite)
                                .reduce((acc, l) => acc + (l.contractorPaidAmount || 0), 0)
                                .toLocaleString()}
                            </p>
                          </div>
                          <div className="bg-white/[0.02] p-4 text-center">
                            <p className="text-[8px] uppercase text-slate-500 tracking-widest mb-1">Personnel Assigned</p>
                            <p className="text-xl font-serif text-white">
                              {labourers.filter(l => l.workSite === selectedSite).length}
                            </p>
                          </div>
                        </div>
                      )}

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label className="text-[10px] uppercase text-slate-500 tracking-widest">Total Contract Value (₹)</label>
                          <Input 
                            type="number"
                            value={siteValue}
                            onChange={e => setSiteValue(Number(e.target.value))}
                            placeholder="REVENUE..."
                            className="bg-white/5 border-white/10 rounded-none h-10 text-xs"
                          />
                        </div>
                        {isManualSettlement && (
                          <div className="space-y-2">
                            <label className="text-[10px] uppercase text-slate-500 tracking-widest">Manual Costs (₹)</label>
                            <Input 
                              type="number"
                              value={manualSettledCost}
                              onChange={e => setManualSettledCost(Number(e.target.value))}
                              placeholder="COSTS..."
                              className="bg-white/5 border-white/10 rounded-none h-10 text-xs"
                            />
                          </div>
                        )}
                      </div>

                      <div className="p-4 bg-accent-blue/5 border border-accent-blue/20 flex justify-between items-center group">
                        <div>
                          <p className="text-[8px] uppercase text-slate-400 tracking-widest">Settlement Net Balance</p>
                          {(() => {
                            const cost = isManualSettlement ? manualSettledCost : labourers.filter(l => l.workSite === selectedSite).reduce((acc, l) => acc + (l.contractorPaidAmount || 0), 0);
                            const balance = siteValue - cost;
                            return (
                              <p className={`text-xl font-serif ${balance < 0 ? 'text-accent-amber' : 'text-accent-blue'}`}>
                                {appSettings.currency}{balance.toLocaleString()}
                              </p>
                            );
                          })()}
                        </div>
                        <CheckCircle2 className="w-8 h-8 text-accent-blue/20" />
                      </div>
                    </div>
                  )}
                </div>

                <Button 
                  disabled={isManualSettlement ? (!manualSiteName || siteValue === 0) : (!selectedSite || siteValue === 0)}
                  onClick={() => {
                    const siteName = isManualSettlement ? manualSiteName : selectedSite;
                    const settledAmount = isManualSettlement ? manualSettledCost : labourers.filter(l => l.workSite === selectedSite).reduce((acc, l) => acc + (l.contractorPaidAmount || 0), 0);
                    
                    const newSettlement: SiteSettlement = {
                      siteName,
                      totalContractValue: siteValue,
                      settledAmount,
                      status: 'Settled',
                      lastUpdated: new Date().toISOString()
                    };
                    setSiteSettlements([...siteSettlements, newSettlement]);
                    setIsSiteSettlementOpen(false);
                    setSelectedSite("");
                    setManualSiteName("");
                    setSiteValue(0);
                    setManualSettledCost(0);
                    toast.success(`Site Settlement Finalized: ${siteName}`);
                  }}
                  className="w-full bg-accent-blue text-bg-primary hover:bg-white transition-colors rounded-none font-sans uppercase tracking-[0.2em] text-[10px] h-12 disabled:opacity-50"
                >
                  Commit Site Settlement
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog open={isSettlementLedgerOpen} onOpenChange={setIsSettlementLedgerOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="rounded-none border-accent-blue/30 text-white text-[10px] uppercase tracking-widest h-10 hover:bg-white hover:text-black shadow-[0_0_15px_rgba(96,165,250,0.15)] bg-accent-blue/5">
                <Banknote className="w-3 h-3 mr-2" /> Settlement Ledger
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-bg-primary border-white/10 text-white rounded-none sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle className="font-serif italic text-xl">Fiscal Settlement Ledger</DialogTitle>
              </DialogHeader>
              <ScrollArea className="h-[400px] font-mono pr-4">
                {siteSettlements.length === 0 ? (
                  <div className="text-center py-20 text-slate-500 text-[10px] uppercase tracking-widest">No site settlements recorded</div>
                ) : (
                  <div className="space-y-4">
                    {siteSettlements.map((s, idx) => (
                      <div key={idx} className="p-4 bg-white/5 border border-white/10 space-y-3">
                        <div className="flex justify-between items-start">
                          <div>
                            <p className="text-[10px] text-white font-bold uppercase">{s.siteName}</p>
                            <p className="text-[8px] text-slate-500 uppercase tracking-tighter">Finalized: {new Date(s.lastUpdated).toLocaleString()}</p>
                          </div>
                          <Badge className="bg-accent-blue text-bg-primary rounded-none text-[8px] uppercase tracking-widest font-bold">
                            {s.status}
                          </Badge>
                        </div>
                        <div className="grid grid-cols-2 gap-4 border-t border-white/5 pt-3">
                          <div>
                            <p className="text-[8px] text-slate-500 uppercase">Contract Value</p>
                            <p className="text-xs text-white">{appSettings.currency}{s.totalContractValue.toLocaleString()}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-[8px] text-slate-500 uppercase">Settled Cost</p>
                            <p className="text-xs text-white">{appSettings.currency}{s.settledAmount.toLocaleString()}</p>
                          </div>
                        </div>
                        <div className="bg-white/5 p-2 text-center">
                          <p className="text-[8px] text-slate-500 uppercase mb-1">Net Surplus/Deficit</p>
                          <p className={`text-base font-serif ${s.totalContractValue - s.settledAmount >= 0 ? 'text-accent-blue' : 'text-accent-amber'}`}>
                            {appSettings.currency}{(s.totalContractValue - s.settledAmount).toLocaleString()}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </DialogContent>
          </Dialog>

          <Dialog open={isSellOpen} onOpenChange={setIsSellOpen}>
          <DialogTrigger asChild>
            <Button className="rounded-none bg-accent-blue text-bg-primary text-[10px] uppercase tracking-widest h-10 hover:bg-white transition-colors">
              <ShoppingCart className="w-3 h-3 mr-2" /> Execute Sale
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-bg-primary border-white/10 text-white rounded-none sm:max-w-[450px]">
            <DialogHeader>
              <DialogTitle className="font-serif italic text-xl">Transaction Terminal</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4 font-mono">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] uppercase text-slate-500 font-mono">Registry Item (Optional)</label>
                  <Select 
                    value={manualSale.itemId} 
                    onValueChange={(val) => {
                      const item = inventory.find(i => i.id === val);
                      setManualSale({ 
                        ...manualSale, 
                        itemId: val, 
                        customName: item?.name || "", 
                        unitPrice: item ? (item.unitPrice - item.discount) : 0 
                      });
                    }}
                  >
                    <SelectTrigger className="bg-white/5 border-white/10 rounded-none h-10 text-xs">
                      <SelectValue placeholder="SELECT ITEM..." />
                    </SelectTrigger>
                    <SelectContent className="bg-bg-primary border-white/10 text-white rounded-none">
                      {inventory.map(item => (
                        <SelectItem key={item.id} value={item.id} className="text-[10px] uppercase focus:bg-white/5 font-mono">
                          {item.name} ({item.quantity} {item.unit})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <label className="text-[10px] uppercase text-slate-500 font-mono">Client Allocation</label>
                  <Select 
                    value={manualSale.customerId} 
                    onValueChange={val => setManualSale({...manualSale, customerId: val})}
                  >
                    <SelectTrigger className="bg-white/5 border-white/10 rounded-none h-10 text-xs text-white uppercase tracking-tight">
                      <SelectValue placeholder="SELECT CLIENT..." />
                    </SelectTrigger>
                    <SelectContent className="bg-bg-primary border-white/10 text-white rounded-none">
                      <SelectItem value="walk-in" className="text-[10px] uppercase focus:bg-white/5 font-mono">Walk-in Traffic</SelectItem>
                      <SelectItem value="new" className="text-[10px] uppercase focus:bg-white/5 font-mono italic text-accent-blue">+ Register New Client</SelectItem>
                      {customers.map(c => (
                        <SelectItem key={c.id} value={c.id} className="text-[10px] uppercase focus:bg-white/5 font-mono">
                          {c.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {manualSale.customerId === "new" && (
                <div className="space-y-2 animate-in fade-in slide-in-from-top-1 duration-300">
                  <label className="text-[10px] uppercase text-slate-500 font-mono">New Client Entry</label>
                  <Input 
                    value={manualSale.newCustomerName}
                    onChange={e => setManualSale({...manualSale, newCustomerName: e.target.value})}
                    placeholder="ENTER FULL NAME..."
                    className="bg-white/5 border-white/10 rounded-none h-10 text-xs"
                  />
                </div>
              )}

              {!manualSale.itemId && (
                <div className="space-y-2">
                  <label className="text-[10px] uppercase text-slate-500">Manual Designation</label>
                  <Input 
                    placeholder="ENTER ITEM NAME..."
                    value={manualSale.customName}
                    onChange={e => setManualSale({...manualSale, customName: e.target.value})}
                    className="bg-white/5 border-white/10 rounded-none h-10 text-xs"
                  />
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] uppercase text-slate-500">Quantity</label>
                  <Input 
                    type="number"
                    value={manualSale.quantity}
                    onChange={e => setManualSale({...manualSale, quantity: Number(e.target.value)})}
                    className="bg-white/5 border-white/10 rounded-none h-10 text-xs"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] uppercase text-slate-500">Rate (₹)</label>
                  <Input 
                    type="number"
                    value={manualSale.unitPrice}
                    onChange={e => setManualSale({...manualSale, unitPrice: Number(e.target.value)})}
                    className="bg-white/5 border-white/10 rounded-none h-10 text-xs"
                  />
                </div>
              </div>

              <div className="p-4 bg-white/[0.03] border border-white/10 space-y-4">
                <div className="flex justify-between items-center pb-4 border-b border-white/5">
                  <div className="space-y-0.5">
                    <Label className="text-[10px] uppercase text-slate-500">Payment Status</Label>
                    <p className="text-[8px] text-slate-600 font-mono uppercase">Full Settlement Required?</p>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className={`text-[9px] uppercase font-mono ${!manualSale.isPaid ? 'text-accent-amber' : 'text-slate-600'}`}>Pending</span>
                    <Switch 
                      checked={manualSale.isPaid} 
                      onCheckedChange={(val) => setManualSale({...manualSale, isPaid: val, paidAmount: val ? (manualSale.quantity * manualSale.unitPrice) : 0})}
                    />
                    <span className={`text-[9px] uppercase font-mono ${manualSale.isPaid ? 'text-accent-blue' : 'text-slate-600'}`}>Paid</span>
                  </div>
                </div>

                {!manualSale.isPaid ? (
                  <div className="space-y-2 animate-in fade-in slide-in-from-top-1 duration-300">
                    <label className="text-[10px] uppercase text-slate-500">Collected Amount (₹)</label>
                    <Input 
                      type="number"
                      value={manualSale.paidAmount}
                      onChange={e => setManualSale({...manualSale, paidAmount: Number(e.target.value)})}
                      className="bg-white/5 border-white/10 rounded-none h-10 text-xs"
                    />
                  </div>
                ) : (
                  <div className="space-y-2 animate-in fade-in duration-300">
                    <label className="text-[10px] uppercase text-slate-500">Payment Channel</label>
                    <div className="flex gap-2">
                      <Button 
                        variant="ghost" 
                        onClick={() => setManualSale({...manualSale, paymentMethod: 'Cash'})}
                        className={`flex-1 rounded-none border border-white/10 h-10 text-[9px] uppercase tracking-widest ${manualSale.paymentMethod === 'Cash' ? 'bg-white text-black' : 'text-slate-500 hover:text-white'}`}
                      >
                        <Banknote className="w-3 h-3 mr-2" /> Cash
                      </Button>
                      <Button 
                        variant="ghost" 
                        onClick={() => setManualSale({...manualSale, paymentMethod: 'Online'})}
                        className={`flex-1 rounded-none border border-white/10 h-10 text-[9px] uppercase tracking-widest ${manualSale.paymentMethod === 'Online' ? 'bg-white text-black' : 'text-slate-500 hover:text-white'}`}
                      >
                        <CreditCard className="w-3 h-3 mr-2" /> Online
                      </Button>
                    </div>
                  </div>
                )}

                <div className="flex justify-between items-center pt-2">
                  <span className="text-[10px] tracking-widest text-slate-400 uppercase">GROSS TOTAL</span>
                  <span className="text-accent-blue text-lg font-bold">₹{(manualSale.quantity * manualSale.unitPrice).toLocaleString()}</span>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button 
                onClick={handleExecuteSale}
                className="w-full bg-white text-bg-primary hover:bg-slate-200 transition-colors rounded-none font-sans uppercase tracking-[0.2em] text-[10px] h-12"
              >
                Confirm Sale Transaction
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>

      <div className="grid grid-cols-1 md:grid-cols-5 gap-px bg-white/5 border border-white/5">
        <Dialog open={isInventoryMgmtOpen} onOpenChange={setIsInventoryMgmtOpen}>
          <DialogTrigger asChild>
            <button className="bg-bg-primary p-6 text-left hover:bg-white/[0.03] transition-colors group">
              <p className="text-[10px] uppercase tracking-widest text-slate-500 mb-2 flex justify-between items-center">
                Total Inventory
                <Edit2 className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
              </p>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-serif text-white">{inventory.length}</span>
                <span className="text-[10px] text-slate-500 uppercase">SKUs</span>
              </div>
            </button>
          </DialogTrigger>
          <DialogContent className="bg-bg-primary border-white/10 text-white rounded-none sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle className="font-serif italic text-xl">Quick Inventory Sync</DialogTitle>
            </DialogHeader>
            <ScrollArea className="h-[400px] mt-4 pr-4">
              <div className="space-y-3">
                {inventory.map(item => (
                  <div key={item.id} className="p-3 bg-white/5 border border-white/10 flex justify-between items-center group">
                    <div>
                      <p className="text-[10px] font-bold text-white uppercase">{item.name}</p>
                      <p className="text-[8px] text-slate-500 font-mono tracking-tighter">Current: {item.quantity} {item.unit}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button 
                        size="icon" 
                        variant="ghost" 
                        className="h-8 w-8 rounded-none border border-white/5"
                        onClick={() => {
                          const updated = inventory.map(ki => ki.id === item.id ? {...ki, quantity: Math.max(0, ki.quantity - 1)} : ki);
                          setInventory(updated);
                        }}
                      >
                        -
                      </Button>
                      <span className="w-8 text-center text-xs font-mono">{item.quantity}</span>
                      <Button 
                        size="icon" 
                        variant="ghost" 
                        className="h-8 w-8 rounded-none border border-white/5"
                        onClick={() => {
                          const updated = inventory.map(ki => ki.id === item.id ? {...ki, quantity: ki.quantity + 1} : ki);
                          setInventory(updated);
                        }}
                      >
                        +
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </DialogContent>
        </Dialog>

        <Dialog open={isAlertsMgmtOpen} onOpenChange={setIsAlertsMgmtOpen}>
          <DialogTrigger asChild>
            <button className="bg-bg-primary p-6 text-left hover:bg-white/[0.03] transition-colors group">
              <p className="text-[10px] uppercase tracking-widest text-slate-500 mb-2 flex justify-between items-center">
                Critical Alerts
                <AlertTriangle className={`w-3 h-3 ${lowStockCount > 0 ? 'text-accent-amber animate-pulse' : 'opacity-0'}`} />
              </p>
              <div className="flex items-baseline gap-2">
                <span className={`text-3xl font-serif ${lowStockCount > 0 ? 'text-accent-amber' : 'text-white'}`}>{lowStockCount}</span>
                <span className="text-[10px] text-slate-500 uppercase italic">Stock Depleted</span>
              </div>
            </button>
          </DialogTrigger>
          <DialogContent className="bg-bg-primary border-white/10 text-white rounded-none sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle className="font-serif italic text-xl">Crisis Management Protocol</DialogTitle>
            </DialogHeader>
            <ScrollArea className="h-[400px] mt-4 pr-4">
              {lowStockCount === 0 ? (
                <div className="flex flex-col items-center justify-center h-full py-20 opacity-50">
                  <CheckCircle2 className="w-12 h-12 text-accent-blue mb-4" />
                  <p className="text-[10px] uppercase tracking-widest text-white">All systems stable</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {inventory.filter(i => i.quantity <= i.minStock).map(item => (
                    <div key={item.id} className="p-4 bg-accent-amber/5 border border-accent-amber/20 space-y-3">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="text-xs font-bold text-accent-amber uppercase">{item.name}</p>
                          <p className="text-[8px] text-slate-400 font-mono">Current: {item.quantity} / Min: {item.minStock}</p>
                        </div>
                        <Badge className="bg-accent-amber text-bg-primary rounded-none text-[8px] uppercase tracking-widest">Low</Badge>
                      </div>
                      <Button 
                        onClick={() => {
                          const updated = inventory.map(ki => ki.id === item.id ? {...ki, quantity: ki.minStock + 10} : ki);
                          setInventory(updated);
                          toast.success(`Refilled ${item.name} (+10)`);
                        }}
                        variant="outline" 
                        className="w-full rounded-none h-8 text-[9px] uppercase tracking-widest border-accent-amber/30 text-accent-amber hover:bg-accent-amber hover:text-bg-primary"
                      >
                        Refill Protocol (+10)
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </ScrollArea>
          </DialogContent>
        </Dialog>

        <Dialog open={isWorkforceMgmtOpen} onOpenChange={setIsWorkforceMgmtOpen}>
          <DialogTrigger asChild>
            <button className="bg-bg-primary p-6 text-left hover:bg-white/[0.03] transition-colors group">
              <p className="text-[10px] uppercase tracking-widest text-slate-500 mb-2 flex justify-between items-center">
                Active Labour
                <Users className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
              </p>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-serif text-white">{activeLabourCount}</span>
                <span className="text-[10px] text-slate-500 uppercase italic">of {labourers.length} Deployed</span>
              </div>
            </button>
          </DialogTrigger>
          <DialogContent className="bg-bg-primary border-white/10 text-white rounded-none sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle className="font-serif italic text-xl">Workforce Matrix Sync</DialogTitle>
            </DialogHeader>
            <ScrollArea className="h-[400px] mt-4 pr-4">
              <div className="space-y-4">
                {labourers.map(labourer => (
                  <div key={labourer.id} className="p-4 bg-white/5 border border-white/10 flex justify-between items-center group">
                    <div>
                      <p className="text-xs font-bold text-white uppercase">{labourer.name}</p>
                      <p className="text-[8px] text-slate-500 font-mono uppercase tracking-widest">{labourer.role}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <p className={`text-[8px] uppercase tracking-widest ${labourer.status === 'Available' ? 'text-accent-blue' : 'text-accent-amber'}`}>
                          {labourer.status === 'Available' ? 'Awaiting Data' : 'Deployed'}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button 
                          size="icon" 
                          variant="ghost" 
                          className="h-8 w-8 rounded-none border border-white/5 hover:bg-white hover:text-bg-primary transition-colors"
                          onClick={() => {
                            setEditingLabourer(labourer);
                            setIsLabourerEditOpen(true);
                          }}
                        >
                          <Edit2 className="w-3 h-3" />
                        </Button>
                        <Switch 
                          checked={labourer.status === 'On Assignment'} 
                          onCheckedChange={(val) => {
                            const updated = labourers.map(l => l.id === labourer.id ? {...l, status: val ? 'On Assignment' : 'Available'} : l);
                            setLabourers(updated);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </DialogContent>
        </Dialog>

        <Dialog open={isOrdersMgmtOpen} onOpenChange={setIsOrdersMgmtOpen}>
          <DialogTrigger asChild>
            <button className="bg-bg-primary p-6 text-left hover:bg-white/[0.03] transition-colors group">
              <p className="text-[10px] uppercase tracking-widest text-slate-500 mb-2 flex justify-between items-center">
                Open Orders
                <History className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
              </p>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-serif text-white">{openOrdersCount}</span>
                <span className="text-[10px] text-slate-500 uppercase italic">Awaiting Payment</span>
              </div>
            </button>
          </DialogTrigger>
          <DialogContent className="bg-bg-primary border-white/10 text-white rounded-none sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle className="font-serif italic text-xl">Pending Settlement</DialogTitle>
            </DialogHeader>
            <ScrollArea className="h-[400px] mt-4 pr-4">
              <div className="space-y-4">
                {transactions.filter(t => t.paymentStatus !== 'Paid').map(txn => (
                  <div key={txn.id} className="p-4 bg-white/5 border border-white/10 space-y-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-[10px] font-bold text-white uppercase">{txn.customerName}</p>
                        <p className="text-[8px] text-slate-500 font-mono italic">{new Date(txn.timestamp).toLocaleString()}</p>
                      </div>
                      <Badge className="bg-accent-amber text-bg-primary rounded-none text-[8px] uppercase tracking-widest">
                        {txn.paymentStatus}
                      </Badge>
                    </div>
                    <div className="flex justify-between items-end border-t border-white/5 pt-2">
                      <p className="text-[10px] font-mono text-white">
                        {appSettings.currency}{txn.totalAmount.toLocaleString()}
                      </p>
                      <Button 
                        size="sm"
                        variant="outline"
                        className="h-7 rounded-none text-[8px] uppercase tracking-widest border-accent-blue/30 text-accent-blue hover:bg-accent-blue hover:text-bg-primary transition-all"
                        onClick={() => {
                          const updated = transactions.map(t => t.id === txn.id ? {...t, paymentStatus: 'Paid' as const, paidAmount: t.totalAmount} : t);
                          setTransactions(updated);
                          toast.success("Transaction Fully Settled");
                        }}
                      >
                        Settle Record
                      </Button>
                    </div>
                  </div>
                ))}
                {transactions.filter(t => t.paymentStatus !== 'Paid').length === 0 && (
                  <div className="text-center py-20 text-slate-600 font-mono text-[10px] uppercase">No pending accounts.</div>
                )}
              </div>
            </ScrollArea>
          </DialogContent>
        </Dialog>

        <Dialog open={isTasksMgmtOpen} onOpenChange={setIsTasksMgmtOpen}>
          <DialogTrigger asChild>
            <button className="bg-bg-primary p-6 text-left hover:bg-white/[0.03] transition-colors group">
              <p className="text-[10px] uppercase tracking-widest text-slate-500 mb-2 flex justify-between items-center">
                Active Work
                <Activity className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
              </p>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-serif text-white">{activeTasksCount}</span>
                <span className="text-[10px] text-slate-500 uppercase italic">Cycles Running</span>
              </div>
            </button>
          </DialogTrigger>
          <DialogContent className="bg-bg-primary border-white/10 text-white rounded-none sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle className="font-serif italic text-xl">Cycle Management Interface</DialogTitle>
            </DialogHeader>
            <ScrollArea className="h-[450px] mt-4 pr-4">
              <div className="space-y-4">
                {tasks.filter(t => t.status !== 'Completed').map(task => (
                  <div key={task.id} className="p-4 bg-white/5 border border-white/10 space-y-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-[10px] font-bold text-white uppercase">{task.title}</p>
                        <p className="text-[8px] text-slate-500 uppercase tracking-widest italic">{task.priority} Priority</p>
                      </div>
                      <Badge className="bg-accent-blue text-bg-primary rounded-none text-[8px] uppercase tracking-widest font-bold">
                        {task.status}
                      </Badge>
                    </div>
                    
                    <div className="flex gap-2">
                      <Button 
                        size="sm"
                        variant="outline"
                        className="flex-1 h-8 rounded-none text-[8px] uppercase tracking-widest border-white/10 text-slate-400 hover:text-white"
                        onClick={() => {
                          const updated = tasks.map(t => t.id === task.id ? {...t, status: t.status === 'Pending' ? 'In Progress' : 'Pending'} : t);
                          setTasks(updated);
                        }}
                      >
                        {task.status === 'Pending' ? 'Initiate Cycle' : 'Suspend Cycle'}
                      </Button>
                      <Button 
                        size="sm"
                        className="flex-1 h-8 bg-accent-blue text-bg-primary rounded-none text-[8px] uppercase tracking-widest hover:bg-white transition-all font-bold"
                        onClick={() => {
                          const updated = tasks.map(t => t.id === task.id ? {...t, status: 'Completed', completedDate: new Date().toISOString()} : t);
                          setTasks(updated);
                          toast.success("Task Cycle Concluded Successfully");
                        }}
                      >
                        Mark Concluded
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </DialogContent>
        </Dialog>

        <Dialog open={isLabourerEditOpen} onOpenChange={setIsLabourerEditOpen}>
          <DialogContent className="bg-bg-primary border-white/10 text-white rounded-none sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle className="font-serif italic text-xl">Personnel Deployment Logistics</DialogTitle>
            </DialogHeader>
            {editingLabourer && (
              <div className="grid gap-4 py-4 font-mono">
                <div className="p-3 bg-white/[0.02] border border-white/5 space-y-1">
                  <p className="text-[10px] uppercase text-white font-bold">{editingLabourer.name}</p>
                  <p className="text-[8px] text-slate-500 uppercase tracking-widest">{editingLabourer.role}</p>
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase text-slate-500 tracking-[0.2em]">Work Site Assignment</label>
                    <Input 
                      value={editingLabourer.workSite || ""}
                      onChange={e => setEditingLabourer({...editingLabourer, workSite: e.target.value})}
                      placeholder="DESIGNATE SITE..."
                      className="bg-white/5 border-white/10 rounded-none h-10 text-xs"
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <label className="text-[10px] uppercase text-slate-500 tracking-[0.2em]">Deployment Progress</label>
                      <span className="text-[10px] text-accent-blue">{editingLabourer.progress || 0}%</span>
                    </div>
                    <div className="relative h-2 bg-white/5 border border-white/10">
                      <div 
                        className="absolute h-full bg-accent-blue transition-all duration-500" 
                        style={{ width: `${editingLabourer.progress || 0}%` }}
                      />
                      <input 
                        type="range"
                        min="0"
                        max="100"
                        value={editingLabourer.progress || 0}
                        onChange={e => setEditingLabourer({...editingLabourer, progress: Number(e.target.value)})}
                        className="absolute inset-0 w-full opacity-0 cursor-pointer"
                      />
                    </div>
                    <p className="text-[8px] text-slate-600 uppercase tracking-tighter">Adjust threshold for completion trace</p>
                  </div>

                  <div className="p-4 bg-white/[0.03] border border-white/10 space-y-4">
                    <p className="text-[10px] uppercase text-slate-400 border-b border-white/5 pb-2 tracking-widest">Financial Settlement (Contractor)</p>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-[10px] uppercase text-slate-500">Amount Settled (₹)</label>
                        <Input 
                          type="number"
                          value={editingLabourer.contractorPaidAmount || 0}
                          onChange={e => setEditingLabourer({...editingLabourer, contractorPaidAmount: Number(e.target.value)})}
                          className="bg-white/5 border-white/10 rounded-none h-10 text-xs"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] uppercase text-slate-500">Payment Protocol</label>
                        <Select 
                          value={editingLabourer.contractorPaymentMethod || 'N/A'}
                          onValueChange={(val: any) => setEditingLabourer({...editingLabourer, contractorPaymentMethod: val})}
                        >
                          <SelectTrigger className="bg-white/5 border-white/10 rounded-none h-10 text-xs">
                            <SelectValue placeholder="METHOD..." />
                          </SelectTrigger>
                          <SelectContent className="bg-bg-primary border-white/10 text-white rounded-none">
                            <SelectItem value="Cash" className="text-[10px] uppercase font-mono">Cash Ledger</SelectItem>
                            <SelectItem value="Online" className="text-[10px] uppercase font-mono">Digital Relay</SelectItem>
                            <SelectItem value="N/A" className="text-[10px] uppercase font-mono">Unsettled</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
            <DialogFooter>
              <Button 
                onClick={handleUpdateLabourer}
                className="w-full bg-accent-blue text-bg-primary hover:bg-white transition-colors rounded-none font-sans uppercase tracking-[0.2em] text-[10px] h-12"
              >
                Authorize Personnel Logistics
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
        <div className="md:col-span-7">
          <Card className="border-none shadow-none bg-transparent">
            <CardHeader className="p-0 mb-6">
              <CardTitle className="text-xl font-serif italic text-white flex items-center gap-2">
                Deployment Analytics
              </CardTitle>
              <CardDescription className="uppercase tracking-[0.2em] text-[9px] text-slate-500">Live workforce & demand sync</CardDescription>
            </CardHeader>
            <CardContent className="p-0 border border-white/5 bg-white/[0.02]">
              <div className="p-6">
                <div className="space-y-6">
                  {tasks.slice(0, 3).map(task => (
                    <div key={task.id} className="group cursor-default">
                      <div className="flex justify-between items-end mb-2">
                        <div>
                          <p className="text-[10px] uppercase tracking-widest text-slate-500 mb-0.5">Project ID: {task.id}</p>
                          <p className="text-sm text-slate-200 group-hover:text-accent-blue transition-colors">{task.title}</p>
                        </div>
                        <Badge variant="outline" className="border-white/10 text-[8px] bg-transparent text-slate-400">
                          {task.status}
                        </Badge>
                      </div>
                      <div className="w-full h-px bg-white/5 relative overflow-hidden">
                        <div className="absolute inset-0 bg-accent-blue/40 w-2/3"></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="md:col-span-5">
          <Card className="border-none shadow-none bg-transparent">
            <CardHeader className="p-0 mb-6 text-right">
              <CardTitle className="text-xl font-serif italic text-white">Stock Allocation</CardTitle>
              <CardDescription className="uppercase tracking-[0.2em] text-[9px] text-slate-500">Volume by category node</CardDescription>
            </CardHeader>
            <CardContent className="h-[280px] p-0 flex flex-col items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={90}
                    paddingAngle={2}
                    dataKey="value"
                    stroke="none"
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#0A0A0B', border: '1px solid rgba(255,255,255,0.1)', color: '#FFFFFF' }}
                    itemStyle={{ fontFamily: 'monospace', fontSize: '10px' }}
                  />
                </PieChart>
              </ResponsiveContainer>
              <div className="flex gap-4 flex-wrap justify-center mt-4">
                {categoryData.map((d, i) => (
                  <div key={d.name} className="flex items-center gap-2">
                    <div className="w-2 h-2" style={{ backgroundColor: COLORS[i % COLORS.length] }}></div>
                    <span className="text-[9px] uppercase tracking-tighter text-slate-500">{d.name}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

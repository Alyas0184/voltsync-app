/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { InventoryItem, ForecastData } from "../types";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "./ui/dialog";
import { Brain, PackagePlus, Search, TrendingUp, Loader2, DollarSign, ShoppingCart, Edit2, Trash2 } from "lucide-react";
import { getDemandForecast } from "../services/geminiService";
import { toast } from "sonner";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";

interface InventoryProps {
  inventory: InventoryItem[];
  setInventory: React.Dispatch<React.SetStateAction<InventoryItem[]>>;
}

export function Inventory({ inventory, setInventory }: InventoryProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [isForecasting, setIsForecasting] = useState(false);
  const [forecasts, setForecasts] = useState<ForecastData[]>([]);
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);

  const [newItem, setNewItem] = useState<Partial<InventoryItem>>({
    name: "",
    category: "General",
    quantity: 0,
    unit: "pcs",
    minStock: 5,
    unitPrice: 0,
    discount: 0,
    paidAmount: 0,
  });

  const handleAddStock = () => {
    if (!newItem.name || !newItem.unitPrice) {
      toast.error("Please provide item name and price.");
      return;
    }

    const itemToAdd: InventoryItem = {
      id: Math.random().toString(36).substr(2, 9),
      name: newItem.name!,
      category: newItem.category!,
      quantity: Number(newItem.quantity) || 0,
      unit: newItem.unit!,
      minStock: Number(newItem.minStock) || 0,
      unitPrice: Number(newItem.unitPrice) || 0,
      discount: Number(newItem.discount) || 0,
      paidAmount: Number(newItem.paidAmount) || 0,
      lastRestocked: new Date().toISOString().split('T')[0],
    };

    setInventory([...inventory, itemToAdd]);
    setIsAddOpen(false);
    setNewItem({
      name: "",
      category: "General",
      quantity: 0,
      unit: "pcs",
      minStock: 5,
      unitPrice: 0,
      discount: 0,
      paidAmount: 0,
    });
    toast.success("Stock Added Successfully");
  };

  const handleUpdateStock = () => {
    if (!editingItem || !editingItem.name || !editingItem.unitPrice) {
      toast.error("Protocol Error: Fields missing.");
      return;
    }

    setInventory(inventory.map(item => item.id === editingItem.id ? editingItem : item));
    setIsEditOpen(false);
    setEditingItem(null);
    toast.success("Registry Record Updated Securely");
  };

  const openEditDialog = (item: InventoryItem) => {
    setEditingItem(item);
    setIsEditOpen(true);
  };

  const handleDeleteItem = (id: string) => {
    if (confirm("Are you sure you want to purge this record from memory?")) {
      setInventory(inventory.filter(item => item.id !== id));
      toast.success("Item expunged from database.");
    }
  };

  const filteredInventory = inventory.filter(item =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleForecasting = async () => {
    setIsForecasting(true);
    try {
      const data = await getDemandForecast(inventory);
      setForecasts(data);
      toast.success("AI Demand Forecast Generated");
    } catch (error) {
      toast.error("Failed to generate forecast");
    } finally {
      setIsForecasting(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white/[0.02] p-6 border border-white/5">
        <div>
          <h2 className="text-xl font-serif italic text-white">Resource Catalog</h2>
          <p className="text-[10px] uppercase tracking-[0.2em] text-slate-500 mt-1">Live Inventory Node</p>
        </div>
        <div className="flex gap-4 w-full md:w-auto">
          <div className="flex items-center gap-2 flex-1 md:w-64 bg-bg-primary px-3 py-2 border border-white/10">
            <Search className="w-3 h-3 opacity-30 text-white" />
            <input
              placeholder="FILTER ARCHIVE..."
              className="bg-transparent border-none outline-none text-[10px] w-full font-mono text-white placeholder:text-slate-700 uppercase tracking-widest"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              onClick={handleForecasting} 
              disabled={isForecasting}
              className="rounded-none border-white/10 text-[10px] uppercase tracking-widest hover:bg-white hover:text-black h-10 transition-all font-sans"
            >
              {isForecasting ? <Loader2 className="w-3 h-3 animate-spin mr-2" /> : <Brain className="w-3 h-3 mr-2" />}
              AI Forecast
            </Button>

            <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
              <DialogTrigger asChild>
                <Button className="rounded-none bg-white text-black text-[10px] uppercase tracking-widest h-10 hover:bg-slate-200">
                  <PackagePlus className="w-3 h-3 mr-2" /> Add Stock
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-bg-primary border-white/10 text-white rounded-none sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle className="font-serif italic text-xl">Register New Stock</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4 font-mono">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-[10px] uppercase text-slate-500">Item Name</label>
                      <Input 
                        value={newItem.name} 
                        onChange={(e) => setNewItem({...newItem, name: e.target.value})}
                        className="bg-white/5 border-white/10 rounded-none h-9 text-xs" 
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] uppercase text-slate-500">Category</label>
                      <Input 
                        value={newItem.category} 
                        onChange={(e) => setNewItem({...newItem, category: e.target.value})}
                        className="bg-white/5 border-white/10 rounded-none h-9 text-xs" 
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <label className="text-[10px] uppercase text-slate-500">Initial Quantity</label>
                      <Input 
                        type="number" 
                        value={newItem.quantity} 
                        onChange={(e) => setNewItem({...newItem, quantity: Number(e.target.value)})}
                        className="bg-white/5 border-white/10 rounded-none h-9 text-xs" 
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] uppercase text-slate-500">Unit (pcs/rolls)</label>
                      <Input 
                        value={newItem.unit} 
                        onChange={(e) => setNewItem({...newItem, unit: e.target.value})}
                        className="bg-white/5 border-white/10 rounded-none h-9 text-xs" 
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] uppercase text-slate-500">Min. Stock</label>
                      <Input 
                        type="number" 
                        value={newItem.minStock} 
                        onChange={(e) => setNewItem({...newItem, minStock: Number(e.target.value)})}
                        className="bg-white/5 border-white/10 rounded-none h-9 text-xs" 
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4 pt-2 border-t border-white/5">
                    <div className="space-y-2">
                      <label className="text-[10px] uppercase text-slate-500">Unit Rate (₹)</label>
                      <Input 
                        type="number" 
                        value={newItem.unitPrice} 
                        onChange={(e) => setNewItem({...newItem, unitPrice: Number(e.target.value)})}
                        className="bg-white/5 border-white/10 rounded-none h-9 text-xs" 
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] uppercase text-slate-500">Discount Amount (₹)</label>
                      <Input 
                        type="number" 
                        value={newItem.discount} 
                        onChange={(e) => setNewItem({...newItem, discount: Number(e.target.value)})}
                        className="bg-white/5 border-white/10 rounded-none h-9 text-xs" 
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase text-slate-500">Amount Already Paid (₹)</label>
                    <Input 
                      type="number" 
                      value={newItem.paidAmount} 
                      onChange={(e) => setNewItem({...newItem, paidAmount: Number(e.target.value)})}
                      className="bg-white/5 border-white/10 rounded-none h-9 text-xs" 
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button 
                    onClick={handleAddStock}
                    className="w-full bg-accent-blue text-bg-primary hover:bg-white transition-colors rounded-none font-sans uppercase tracking-[0.2em] text-[10px] h-10"
                  >
                    Commit Stock to Registry
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
              <DialogContent className="bg-bg-primary border-white/10 text-white rounded-none sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle className="font-serif italic text-xl">Modify Stock Record</DialogTitle>
                </DialogHeader>
                {editingItem && (
                  <div className="grid gap-4 py-4 font-mono">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-[10px] uppercase text-slate-500">Item Name</label>
                        <Input 
                          value={editingItem.name} 
                          onChange={(e) => setEditingItem({...editingItem, name: e.target.value})}
                          className="bg-white/5 border-white/10 rounded-none h-9 text-xs" 
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] uppercase text-slate-500">Category</label>
                        <Input 
                          value={editingItem.category} 
                          onChange={(e) => setEditingItem({...editingItem, category: e.target.value})}
                          className="bg-white/5 border-white/10 rounded-none h-9 text-xs" 
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <label className="text-[10px] uppercase text-slate-500">Quantity</label>
                        <Input 
                          type="number" 
                          value={editingItem.quantity} 
                          onChange={(e) => setEditingItem({...editingItem, quantity: Number(e.target.value)})}
                          className="bg-white/5 border-white/10 rounded-none h-9 text-xs" 
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] uppercase text-slate-500">Unit</label>
                        <Input 
                          value={editingItem.unit} 
                          onChange={(e) => setEditingItem({...editingItem, unit: e.target.value})}
                          className="bg-white/5 border-white/10 rounded-none h-9 text-xs" 
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] uppercase text-slate-500">Min. Stock</label>
                        <Input 
                          type="number" 
                          value={editingItem.minStock} 
                          onChange={(e) => setEditingItem({...editingItem, minStock: Number(e.target.value)})}
                          className="bg-white/5 border-white/10 rounded-none h-9 text-xs" 
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4 pt-2 border-t border-white/5">
                      <div className="space-y-2">
                        <label className="text-[10px] uppercase text-slate-500">Unit Rate (₹)</label>
                        <Input 
                          type="number" 
                          value={editingItem.unitPrice} 
                          onChange={(e) => setEditingItem({...editingItem, unitPrice: Number(e.target.value)})}
                          className="bg-white/5 border-white/10 rounded-none h-9 text-xs" 
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] uppercase text-slate-500">Discount (₹)</label>
                        <Input 
                          type="number" 
                          value={editingItem.discount} 
                          onChange={(e) => setEditingItem({...editingItem, discount: Number(e.target.value)})}
                          className="bg-white/5 border-white/10 rounded-none h-9 text-xs" 
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] uppercase text-slate-500">Settled Amount (₹)</label>
                      <Input 
                        type="number" 
                        value={editingItem.paidAmount} 
                        onChange={(e) => setEditingItem({...editingItem, paidAmount: Number(e.target.value)})}
                        className="bg-white/5 border-white/10 rounded-none h-9 text-xs" 
                      />
                    </div>
                  </div>
                )}
                <DialogFooter>
                  <Button 
                    onClick={handleUpdateStock}
                    className="w-full bg-accent-blue text-bg-primary hover:bg-white transition-colors rounded-none font-sans uppercase tracking-[0.2em] text-[10px] h-10"
                  >
                    Authorize Changes
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-10">
        <div className="md:col-span-12 lg:col-span-8">
          <div className="overflow-x-auto">
            <Table className="border-collapse min-w-[800px]">
              <TableHeader>
                <TableRow className="border-white/10 hover:bg-transparent">
                  <TableHead className="font-serif italic text-slate-500 text-sm py-4">Designation</TableHead>
                  <TableHead className="font-serif italic text-slate-500 text-sm py-4">Volume</TableHead>
                  <TableHead className="font-serif italic text-slate-500 text-sm py-4">Rate</TableHead>
                  <TableHead className="font-serif italic text-slate-500 text-sm py-4">Discount</TableHead>
                  <TableHead className="font-serif italic text-slate-500 text-sm py-4">Total Net</TableHead>
                  <TableHead className="font-serif italic text-slate-500 text-sm py-4">Paid</TableHead>
                  <TableHead className="font-serif italic text-slate-500 text-sm py-4 text-center">Actions</TableHead>
                  <TableHead className="font-serif italic text-slate-500 text-sm py-4 text-right">Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredInventory.map((item) => {
                  const netPrice = item.unitPrice - item.discount;
                  const totalNet = netPrice * item.quantity;
                  
                  return (
                    <TableRow key={item.id} className="border-white/5 hover:bg-white/[0.02] transition-colors cursor-pointer group">
                      <TableCell className="py-4">
                        <p className="text-xs text-slate-200 group-hover:text-white transition-colors font-semibold uppercase tracking-tight">{item.name}</p>
                        <p className="text-[9px] text-slate-500 font-mono italic">{item.category}</p>
                      </TableCell>
                      <TableCell className="font-mono text-xs text-white">
                        {item.quantity} <span className="text-[9px] text-slate-500 ml-0.5">{item.unit}</span>
                      </TableCell>
                      <TableCell className="font-mono text-xs text-slate-400">
                        ₹{item.unitPrice.toFixed(2)}
                      </TableCell>
                      <TableCell className="font-mono text-xs text-accent-amber/70">
                        -₹{item.discount.toFixed(2)}
                      </TableCell>
                      <TableCell className="font-mono text-xs text-white underline decoration-white/10">
                        ₹{totalNet.toFixed(2)}
                      </TableCell>
                      <TableCell className="font-mono text-xs text-accent-blue font-bold">
                        ₹{item.paidAmount.toFixed(2)}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center justify-center gap-2">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-7 w-7 rounded-none border border-white/5 hover:bg-white hover:text-black transition-colors"
                            onClick={(e) => {
                              e.stopPropagation();
                              openEditDialog(item);
                            }}
                          >
                            <Edit2 className="w-3 h-3" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-7 w-7 rounded-none border border-white/5 hover:bg-white hover:text-accent-amber transition-colors"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteItem(item.id);
                            }}
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex flex-col items-end gap-1">
                          <span className={`text-[9px] uppercase tracking-widest ${item.quantity <= item.minStock ? 'text-accent-amber' : 'text-slate-600'}`}>
                            {item.quantity <= item.minStock ? 'Critical' : 'Nominal'}
                          </span>
                          <div className="w-12 h-0.5 bg-slate-800">
                            <div 
                              className={`h-full ${item.quantity <= item.minStock ? 'bg-accent-amber' : 'bg-accent-blue'}`} 
                              style={{ width: `${Math.min(100, (item.quantity / (item.minStock * 2)) * 100)}%` }}
                            ></div>
                          </div>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </div>

        <div className="md:col-span-12 lg:col-span-4">
          <section className="sticky top-8">
            <div className="bg-white/[0.01] border border-white/5 p-6 mb-8">
              <h3 className="text-lg font-serif italic text-white flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-accent-blue" /> Financial Ledger
              </h3>
              <p className="text-[10px] text-slate-500 uppercase tracking-widest mt-1 mb-4">Inventory Valuation</p>
              <div className="space-y-4">
                <div className="flex justify-between items-baseline">
                  <span className="text-[10px] text-slate-400 uppercase">Gross Asset Value</span>
                  <span className="text-sm font-mono text-white">
                    ₹{inventory.reduce((acc, item) => acc + ((item.unitPrice || 0) * (item.quantity || 0)), 0).toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between items-baseline">
                  <span className="text-[10px] text-slate-400 uppercase">Total Settled</span>
                  <span className="text-sm font-mono text-accent-blue">
                    ₹{inventory.reduce((acc, item) => acc + (item.paidAmount || 0), 0).toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between items-baseline pt-2 border-t border-white/5">
                  <span className="text-[10px] text-slate-200 uppercase font-bold">Outstanding</span>
                  <span className="text-sm font-mono text-accent-amber">
                    ₹{inventory.reduce((acc, item) => acc + (((item.unitPrice || 0) - (item.discount || 0)) * (item.quantity || 0) - (item.paidAmount || 0)), 0).toLocaleString()}
                  </span>
                </div>
              </div>
            </div>

            <h3 className="text-lg font-serif italic text-white mb-2">Demand Forecast</h3>
            <p className="text-[10px] text-slate-500 leading-relaxed mb-6 italic border-b border-white/5 pb-4">
              Model trained on historical cycles and pipeline velocity.
            </p>
            
            <div className="space-y-4">
              {forecasts.length > 0 ? (
                forecasts.map(f => (
                  <div key={f.itemId} className="p-5 bg-white/[0.03] border border-white/5 rounded-sm space-y-3 group hover:border-white/20 transition-colors">
                    <div className="flex justify-between items-start">
                      <span className="text-xs font-semibold text-white tracking-wide uppercase">{f.itemName}</span>
                      <span className="text-[9px] text-accent-blue font-mono">CONF: {(f.confidence * 100).toFixed(0)}%</span>
                    </div>
                    <p className="text-[11px] text-slate-400 font-serif italic leading-snug">"{f.reasoning}"</p>
                    <div className="pt-2 flex justify-between items-center border-t border-white/5">
                      <div className="text-[9px] uppercase text-slate-500">Suggested Lead:</div>
                      <div className="text-[10px] font-mono text-white underline decoration-white/20 underline-offset-4">{f.suggestedReorderDate}</div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-8 border border-dashed border-white/10 text-center">
                  <p className="text-xs text-slate-600 font-serif italic">Initialize AI protocol for supply chain projection.</p>
                </div>
              )}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}

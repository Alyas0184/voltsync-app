/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Labourer, WorkTask } from "../types";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "./ui/dialog";
import { 
  UserCircle, 
  Briefcase, 
  Clock, 
  UserPlus, 
  Star, 
  Award,
  ChevronDown
} from "lucide-react";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { toast } from "sonner";

interface LabourProps {
  labourers: Labourer[];
  setLabourers: React.Dispatch<React.SetStateAction<Labourer[]>>;
  tasks: WorkTask[];
}

export function LabourManagement({ labourers, setLabourers, tasks }: LabourProps) {
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editingLabourer, setEditingLabourer] = useState<Labourer | null>(null);
  
  const [newLabourer, setNewLabourer] = useState<Partial<Labourer>>({
    name: "",
    role: "Technician",
    status: "Available",
    skills: [],
    hourlyRate: 0,
    yearsOfExperience: 0,
    workSite: "",
    progress: 0,
    contractorPaidAmount: 0,
    contractorPaymentMethod: "N/A" as any
  });

  const handleStatusChange = (id: string, newStatus: string) => {
    setLabourers(prev => prev.map(l => 
      l.id === id ? { ...l, status: newStatus as any } : l
    ));
    toast.success(`Personnel status updated to ${newStatus}`);
  };

  const handleRegister = () => {
    if (!newLabourer.name || !newLabourer.hourlyRate) {
      toast.error("Required fields missing");
      return;
    }

    const created: Labourer = {
      id: `L-${Math.random().toString(36).substr(2, 4)}`,
      name: newLabourer.name!,
      role: newLabourer.role!,
      status: newLabourer.status as any,
      skills: String(newLabourer.skills).split(',').map((s: string) => s.trim()),
      hourlyRate: Number(newLabourer.hourlyRate),
      yearsOfExperience: Number(newLabourer.yearsOfExperience),
      workSite: newLabourer.workSite,
      progress: newLabourer.progress || 0,
      contractorPaidAmount: newLabourer.contractorPaidAmount || 0,
      contractorPaymentMethod: newLabourer.contractorPaymentMethod as any || 'N/A'
    };

    setLabourers([...labourers, created]);
    setIsAddOpen(false);
    toast.success("Personnel Added to Workforce");
  };

  const handleUpdate = () => {
    if (editingLabourer) {
      setLabourers(prev => prev.map(l => l.id === editingLabourer.id ? editingLabourer : l));
      setIsEditOpen(false);
      setEditingLabourer(null);
      toast.success("Personnel Logistics Synchronized");
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white/[0.02] p-6 border border-white/5">
        <div>
          <h2 className="text-xl font-serif italic text-white">Workforce Command</h2>
          <p className="text-[10px] uppercase tracking-[0.2em] text-slate-500 mt-1">Resource Deployment Node</p>
        </div>
        
        <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
          <DialogTrigger asChild>
            <Button className="rounded-none bg-white text-black text-[10px] uppercase tracking-widest h-10 hover:bg-slate-200">
              <UserPlus className="w-3 h-3 mr-2" /> Register Labourer
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-bg-primary border-white/10 text-white rounded-none sm:max-w-[450px]">
            <DialogHeader>
              <DialogTitle className="font-serif italic text-xl text-white">New Personnel Entry</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4 font-mono">
              <div className="space-y-2">
                <label className="text-[10px] uppercase text-slate-500">Legal Name</label>
                <Input value={newLabourer.name} onChange={e => setNewLabourer({...newLabourer, name: e.target.value})} className="bg-white/5 border-white/10 rounded-none h-9 text-xs" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] uppercase text-slate-500">Designation</label>
                  <Input value={newLabourer.role} onChange={e => setNewLabourer({...newLabourer, role: e.target.value})} className="bg-white/5 border-white/10 rounded-none h-9 text-xs" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] uppercase text-slate-500">Exp. (Years)</label>
                  <Input type="number" value={newLabourer.yearsOfExperience} onChange={e => setNewLabourer({...newLabourer, yearsOfExperience: Number(e.target.value)})} className="bg-white/5 border-white/10 rounded-none h-9 text-xs" />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] uppercase text-slate-500">Skills (Comma Separated)</label>
                <Input value={newLabourer.skills} onChange={e => setNewLabourer({...newLabourer, skills: e.target.value as any})} className="bg-white/5 border-white/10 rounded-none h-9 text-xs" placeholder="WIRING, PANELS, SOLAR" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] uppercase text-slate-500">Designated Work Site</label>
                <Input value={newLabourer.workSite} onChange={e => setNewLabourer({...newLabourer, workSite: e.target.value})} className="bg-white/5 border-white/10 rounded-none h-9 text-xs" placeholder="SITE A, B, C..." />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] uppercase text-slate-500">Billing Rate (₹/POINT)</label>
                  <Input type="number" value={newLabourer.hourlyRate} onChange={e => setNewLabourer({...newLabourer, hourlyRate: Number(e.target.value)})} className="bg-white/5 border-white/10 rounded-none h-9 text-xs" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] uppercase text-slate-500">Payment Protocol</label>
                  <Select value={newLabourer.contractorPaymentMethod} onValueChange={(val: any) => setNewLabourer({...newLabourer, contractorPaymentMethod: val})}>
                    <SelectTrigger className="bg-white/5 border-white/10 rounded-none h-9 text-xs">
                      <SelectValue placeholder="Protocol" />
                    </SelectTrigger>
                    <SelectContent className="bg-bg-primary border-white/10 text-white rounded-none">
                      <SelectItem value="Cash" className="text-[8px] uppercase">Cash</SelectItem>
                      <SelectItem value="Online" className="text-[8px] uppercase">Online</SelectItem>
                      <SelectItem value="N/A" className="text-[8px] uppercase">N/A</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button onClick={handleRegister} className="w-full bg-accent-blue text-bg-primary hover:bg-white transition-colors rounded-none font-sans uppercase tracking-[0.2em] text-[10px] h-10">
                Authorize Deployment
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
          <DialogContent className="bg-bg-primary border-white/10 text-white rounded-none sm:max-w-[450px]">
            <DialogHeader>
              <DialogTitle className="font-serif italic text-xl text-white">Personnel logistics Matrix</DialogTitle>
            </DialogHeader>
            {editingLabourer && (
              <div className="grid gap-4 py-4 font-mono">
                <div className="space-y-2">
                  <label className="text-[10px] uppercase text-slate-500">Work Site Designation</label>
                  <Input value={editingLabourer.workSite} onChange={e => setEditingLabourer({...editingLabourer, workSite: e.target.value})} className="bg-white/5 border-white/10 rounded-none h-9 text-xs" />
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <label className="text-[10px] uppercase text-slate-500">Progress Trace ({editingLabourer.progress}%)</label>
                  </div>
                  <input 
                    type="range" 
                    min="0" 
                    max="100" 
                    value={editingLabourer.progress} 
                    onChange={e => setEditingLabourer({...editingLabourer, progress: Number(e.target.value)})}
                    className="w-full h-1 bg-white/10 accent-accent-blue cursor-pointer"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase text-slate-500">Amount Paid (₹)</label>
                    <Input type="number" value={editingLabourer.contractorPaidAmount} onChange={e => setEditingLabourer({...editingLabourer, contractorPaidAmount: Number(e.target.value)})} className="bg-white/5 border-white/10 rounded-none h-9 text-xs" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase text-slate-500">Protocol</label>
                    <Select value={editingLabourer.contractorPaymentMethod} onValueChange={(val: any) => setEditingLabourer({...editingLabourer, contractorPaymentMethod: val})}>
                      <SelectTrigger className="bg-white/5 border-white/10 rounded-none h-9 text-xs">
                        <SelectValue placeholder="Protocol" />
                      </SelectTrigger>
                      <SelectContent className="bg-bg-primary border-white/10 text-white rounded-none">
                        <SelectItem value="Cash" className="text-[8px] uppercase">Cash</SelectItem>
                        <SelectItem value="Online" className="text-[8px] uppercase">Online</SelectItem>
                        <SelectItem value="N/A" className="text-[8px] uppercase">N/A</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            )}
            <DialogFooter>
              <Button onClick={handleUpdate} className="w-full bg-accent-blue text-bg-primary hover:bg-white transition-colors rounded-none font-sans uppercase tracking-[0.2em] text-[10px] h-10">
                Synchronize Pulse
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-1 grid-seamless border border-white/5 overflow-hidden">
        {labourers.map(labourer => {
          const activeTask = tasks.find(t => t.assignedLabourerId === labourer.id && t.status === 'In Progress');
          const isExperienced = labourer.yearsOfExperience >= 5;
          const progressPercentage = labourer.progress || 0;
          
          return (
            <div key={labourer.id} className="p-8 space-y-6 group hover:bg-white/[0.02] transition-colors h-full flex flex-col relative overflow-hidden">
              <div className="absolute top-0 left-0 h-1 bg-accent-blue/20 w-full">
                <div className="h-full bg-accent-blue transition-all duration-1000" style={{ width: `${progressPercentage}%` }}></div>
              </div>
              
              {isExperienced && (
                <div className="absolute top-0 right-0 p-2 opacity-20 group-hover:opacity-100 transition-opacity">
                  <Award className="w-8 h-8 text-accent-blue" />
                </div>
              )}
              
              <div className="flex justify-between items-start">
                <div className="w-12 h-12 bg-white/5 border border-white/10 flex items-center justify-center text-xs font-mono text-white group-hover:bg-accent-blue group-hover:text-bg-primary transition-all duration-500">
                  {labourer.name.split(' ').map(n => n[0]).join('')}
                </div>
                <div className="flex flex-col items-end gap-2">
                  <div className="flex gap-2">
                    <Button 
                      size="icon" 
                      variant="ghost" 
                      className="h-6 w-6 border-white/10 rounded-none hover:bg-white/10"
                      onClick={() => {
                        setEditingLabourer(labourer);
                        setIsEditOpen(true);
                      }}
                    >
                      <Briefcase className="w-3 h-3 text-slate-500" />
                    </Button>
                    <Select 
                      defaultValue={labourer.status} 
                      onValueChange={(val) => handleStatusChange(labourer.id, val)}
                    >
                      <SelectTrigger className={`h-6 w-auto border-white/10 bg-transparent text-[8px] uppercase tracking-widest rounded-none px-2 focus:ring-0 ${labourer.status === 'Available' ? 'text-accent-blue/80' : 'text-accent-amber/80'}`}>
                        <SelectValue placeholder="Status" />
                      </SelectTrigger>
                      <SelectContent className="bg-bg-primary border-white/10 text-white rounded-none">
                        <SelectItem value="Available" className="text-[8px] uppercase focus:bg-white/5">Available</SelectItem>
                        <SelectItem value="On Assignment" className="text-[8px] uppercase focus:bg-white/5">On Assignment</SelectItem>
                        <SelectItem value="Away" className="text-[8px] uppercase focus:bg-white/5">Away</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {isExperienced && (
                    <span className="text-[7px] bg-accent-blue/10 text-accent-blue border border-accent-blue/20 px-1 uppercase tracking-tighter italic">Expert Node</span>
                  )}
                </div>
              </div>

              <div>
                <h3 className="text-sm font-semibold text-white tracking-wide uppercase flex items-center gap-2">
                  {labourer.name}
                </h3>
                <p className="text-xs text-slate-500 font-serif italic mt-0.5">{labourer.role} • {labourer.yearsOfExperience}y Experience</p>
                {labourer.workSite && (
                  <p className="text-[9px] text-accent-blue mt-2 font-mono uppercase">Site: {labourer.workSite}</p>
                )}
              </div>

              <div className="flex gap-2 flex-wrap">
                {labourer.skills.map(skill => (
                  <span key={skill} className="text-[8px] uppercase tracking-[0.1em] px-2 py-1 bg-white/5 text-slate-400 border border-white/5">
                    {skill}
                  </span>
                ))}
              </div>

              <div className="mt-auto pt-6 border-t border-white/5 space-y-4">
                <div className="flex justify-between items-center">
                  <p className="text-[9px] uppercase tracking-widest text-slate-600">Trace Progress</p>
                  <span className="text-[9px] font-mono text-accent-blue">{progressPercentage}%</span>
                </div>
                
                {labourer.contractorPaidAmount ? (
                  <div className="flex justify-between items-center text-[9px] font-mono border-b border-white/5 pb-2">
                    <span className="text-slate-500 uppercase">Paid by Contractor</span>
                    <span className="text-green-500/80 font-bold">₹{labourer.contractorPaidAmount} [{labourer.contractorPaymentMethod}]</span>
                  </div>
                ) : (
                   <div className="flex justify-between items-center text-[9px] font-mono border-b border-white/5 pb-2">
                    <span className="text-slate-500 uppercase">Paid by Contractor</span>
                    <span className="text-slate-400">UNSETTLED</span>
                  </div>
                )}

                {activeTask ? (
                  <div>
                    <p className="text-[9px] uppercase tracking-widest text-slate-600 mb-2">Current Deployment</p>
                    <div className="p-3 bg-white/[0.03] border border-white/5 flex items-center justify-between">
                      <span className="text-[10px] text-slate-300 font-mono italic truncate mr-2">{activeTask.title}</span>
                      <div className="w-1.5 h-1.5 bg-accent-blue animate-pulse shrink-0"></div>
                    </div>
                  </div>
                ) : (
                  <div className="py-2 text-[10px] text-slate-600 italic font-serif">
                    Standby Node // Awaiting Assignment
                  </div>
                )}
                
                <div className="flex justify-between items-center text-[10px] font-mono">
                  <span className="text-slate-500 uppercase tracking-tighter">Billed Rate</span>
                  <span className="text-white">₹{labourer.hourlyRate}/POINT</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

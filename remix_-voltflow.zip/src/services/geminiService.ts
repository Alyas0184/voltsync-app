/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GoogleGenAI, Type } from "@google/genai";
import { InventoryItem, ForecastData } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function getDemandForecast(inventory: InventoryItem[]): Promise<ForecastData[]> {
  const prompt = `Analyze this electrical workshop inventory and provide demand forecasting for the next 30 days.
  Focus on identifying items likely to run out based on their current quantity and minStock levels.
  
  Inventory Data:
  ${JSON.stringify(inventory)}
  
  Return a JSON array of objects with these properties:
  - itemId: string
  - itemName: string
  - predictedDemand: number (estimated quantity needed in next 30 days)
  - confidence: number (0.0 to 1.0)
  - reasoning: string (why this demand is predicted)
  - suggestedReorderDate: string (ISO date)`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              itemId: { type: Type.STRING },
              itemName: { type: Type.STRING },
              predictedDemand: { type: Type.NUMBER },
              confidence: { type: Type.NUMBER },
              reasoning: { type: Type.STRING },
              suggestedReorderDate: { type: Type.STRING },
            },
            required: ["itemId", "itemName", "predictedDemand", "confidence", "reasoning", "suggestedReorderDate"],
          },
        },
      },
    });

    return JSON.parse(response.text || "[]");
  } catch (error) {
    return [];
  }
}

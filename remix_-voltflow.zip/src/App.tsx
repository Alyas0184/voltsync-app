/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { INITIAL_INVENTORY, INITIAL_LABOUR, INITIAL_TASKS } from './constants';
import { Dashboard } from './components/Dashboard';
import { Inventory } from './components/Inventory';
import { LabourManagement } from './components/LabourManagement';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Toaster, toast } from 'sonner';
import { Bolt, LayoutDashboard, Package, Users, Settings, Bell, CheckCircle2, AlertTriangle } from 'lucide-react';
import { UserProfile, AppSettings, AppNotification, SaleTransaction, Customer, SiteSettlement } from './types';
import { Popover, PopoverContent, PopoverTrigger } from './components/ui/popover';
import { Button } from './components/ui/button';
import { ScrollArea } from './components/ui/scroll-area';
import { Badge } from './components/ui/badge';
import { format } from 'date-fns';

export default function App() {
  const [inventory, setInventory] = useState(INITIAL_INVENTORY);
  const [labourers, setLabourers] = useState(INITIAL_LABOUR);
  const [tasks, setTasks] = useState(INITIAL_TASKS);
  const [user, setUser] = useState<UserProfile>({ name: "COMMANDER", role: "Site Supervisor" });
  const [appSettings, setAppSettings] = useState<AppSettings>({ 
    theme: 'technical', 
    background: 'default',
    currency: '₹', 
    notifications: true 
  });
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [transactions, setTransactions] = useState<SaleTransaction[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [siteSettlements, setSiteSettlements] = useState<SiteSettlement[]>([]);

  // Monitor stock levels and generate notifications
  useEffect(() => {
    if (!appSettings.notifications) return;

    inventory.forEach(item => {
      if (item.quantity <= item.minStock) {
        const notificationId = `low-stock-${item.id}-${Math.floor(item.quantity)}`;
        
        // Check if we already notified for this specific stock level recently
        setNotifications(prev => {
          if (prev.some(n => n.id === notificationId)) return prev;

          const newNotification: AppNotification = {
            id: notificationId,
            title: "LOW STOCK ALERT",
            message: `Inventory item [${item.name}] is below minimum threshold. Current: ${item.quantity} ${item.unit} | Min: ${item.minStock} ${item.unit}`,
            type: 'warning',
            timestamp: new Date().toISOString(),
            read: false
          };

          // Trigger toast for immediate feedback (simulating the "alert")
          toast.warning(newNotification.title, {
            description: newNotification.message,
            duration: 5000,
          });

          return [newNotification, ...prev].slice(0, 50); // Keep last 50
        });
      }
    });
  }, [inventory, appSettings.notifications]);

  const markAllRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  const lowStockCount = inventory.filter(i => i.quantity <= i.minStock).length;

  const getThemeClass = () => {
    switch(appSettings.theme) {
      case 'monochrome': return 'grayscale contrast-125';
      case 'industrial': return 'sepia-[0.3] contrast-110 hue-rotate-[180deg]';
      case 'classic': return 'brightness-125 saturate-50';
      default: return '';
    }
  };

  const getBgClass = () => {
    switch (appSettings.background) {
      case 'golden': return 'bg-[#1a1600] border-t-2 border-[#d4af37]';
      case 'black': return 'bg-black';
      case 'white': return 'bg-[#f8f9fa]';
      case 'chocolate': return 'bg-[#1b1210]';
      case 'lightgreen': return 'bg-[#f0f9f0]';
      case 'premiumgold': return 'bg-[#2a2408] border-t-4 border-[#FFD700]';
      default: return 'bg-bg-primary';
    }
  };

  const getTextClass = (intensity: 'primary' | 'secondary' | 'muted' = 'primary') => {
    const isLight = appSettings.background === 'white' || appSettings.background === 'lightgreen';
    if (intensity === 'primary') return isLight ? 'text-slate-900' : 'text-white';
    if (intensity === 'secondary') return isLight ? 'text-slate-600' : 'text-slate-300';
    return isLight ? 'text-slate-400' : 'text-slate-500';
  };

  return (
    <div className={`min-h-screen flex flex-col font-sans selection:bg-accent-blue selection:text-bg-primary ${getBgClass()} ${getTextClass('secondary')} transition-all duration-1000 ${getThemeClass()}`}>
      <Toaster position="bottom-right" theme={(appSettings.background === 'white' || appSettings.background === 'lightgreen') ? 'light' : 'dark'} expand={false} />
      
      {/* Header Section */}
      <header className={`border-b ${appSettings.background === 'white' ? 'border-slate-200' : 'border-white/10'} px-8 py-6 flex justify-between items-end`}>
        <div>
          <h1 className={`text-3xl font-serif italic ${getTextClass()} tracking-tight`}>VoltSync Systems</h1>
          <p className="text-[10px] uppercase tracking-[0.2em] text-slate-500 mt-1">Workshop Command & Demand Forecast</p>
        </div>
        <div className="flex gap-8 text-right hidden md:flex items-end">
          <div className="mr-4">
            <Popover>
              <PopoverTrigger asChild>
                <button className={`relative p-2 ${appSettings.background === 'white' ? 'text-slate-400 hover:text-slate-900' : 'text-slate-500 hover:text-white'} transition-colors`}>
                  <Bell className="w-5 h-5" />
                  {unreadCount > 0 && (
                    <span className="absolute top-1 right-1 flex h-4 w-4 items-center justify-center rounded-full bg-accent-blue text-[8px] font-bold text-bg-primary">
                      {unreadCount}
                    </span>
                  )}
                </button>
              </PopoverTrigger>
              <PopoverContent className={`w-80 ${appSettings.background === 'white' ? 'bg-white border-slate-200' : 'bg-bg-primary border-white/10'} p-0 rounded-none shadow-2xl z-50`}>
                <div className={`flex items-center justify-between border-b ${appSettings.background === 'white' ? 'border-slate-100' : 'border-white/5'} p-4`}>
                  <h3 className={`text-[10px] uppercase tracking-widest ${getTextClass()} font-bold`}>Signal Log</h3>
                  <button onClick={markAllRead} className="text-[9px] uppercase tracking-tighter text-slate-500 hover:text-accent-blue font-mono transition-colors">
                    Acknowledge All
                  </button>
                </div>
                <ScrollArea className="h-[350px]">
                  {notifications.length === 0 ? (
                    <div className="flex h-full flex-col items-center justify-center p-8 text-center text-slate-600">
                      <CheckCircle2 className="mb-2 h-8 w-8 opacity-20" />
                      <p className="text-[10px] uppercase font-mono">No active alerts</p>
                    </div>
                  ) : (
                    <div className="flex flex-col">
                      {notifications.map((n) => (
                        <div 
                          key={n.id} 
                          className={`border-b ${appSettings.background === 'white' ? 'border-slate-100' : 'border-white/5'} p-4 transition-colors hover:bg-black/[0.02] ${!n.read ? (appSettings.background === 'white' ? 'bg-slate-50' : 'bg-white/[0.03]') : ''}`}
                        >
                          <div className="flex items-start gap-3">
                            <div className={`mt-1 h-1.5 w-1.5 rounded-full ${n.type === 'warning' ? 'bg-accent-amber' : 'bg-accent-blue'}`} />
                            <div className="flex-1 space-y-1">
                              <div className="flex items-center justify-between">
                                <p className={`text-[10px] font-bold uppercase tracking-tight ${!n.read ? 'text-white' : 'text-slate-400'}`}>
                                  {n.title}
                                </p>
                                <span className="text-[8px] font-mono text-slate-600">
                                  {format(new Date(n.timestamp), 'HH:mm:ss')}
                                </span>
                              </div>
                              <p className="text-[10px] leading-relaxed text-slate-400 font-mono italic">
                                {n.message}
                              </p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </PopoverContent>
            </Popover>
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-widest text-slate-500 mb-1">Authenticated As</p>
            <p className="text-white text-sm font-serif italic">{user.name}</p>
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-widest text-slate-500 mb-1">System Status</p>
            <p className="text-accent-blue text-sm font-medium uppercase font-mono">Stable // {appSettings.theme}</p>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col overflow-hidden">
        <Tabs defaultValue="overview" className="flex-1 flex flex-col">
          <div className="px-8 border-b border-white/5 bg-white/[0.02]">
            <TabsList className="bg-transparent h-12 p-0 gap-8 justify-start">
              <TabsTrigger 
                value="overview" 
                className="rounded-none border-b border-transparent data-[state=active]:border-accent-blue data-[state=active]:bg-transparent px-0 h-11 text-[10px] uppercase tracking-widest text-slate-500 data-[state=active]:text-white transition-all shadow-none"
              >
                Overview
              </TabsTrigger>
              <TabsTrigger 
                value="inventory" 
                className="rounded-none border-b border-transparent data-[state=active]:border-accent-blue data-[state=active]:bg-transparent px-0 h-11 text-[10px] uppercase tracking-widest text-slate-500 data-[state=active]:text-white transition-all shadow-none"
              >
                Inventory
              </TabsTrigger>
              <TabsTrigger 
                value="labour" 
                className="rounded-none border-b border-transparent data-[state=active]:border-accent-blue data-[state=active]:bg-transparent px-0 h-11 text-[10px] uppercase tracking-widest text-slate-500 data-[state=active]:text-white transition-all shadow-none"
              >
                Labour
              </TabsTrigger>
            </TabsList>
          </div>

          <div className="flex-1 overflow-auto p-8 bg-transparent">
            <TabsContent value="overview" className="mt-0 focus-visible:outline-none">
              <Dashboard 
                inventory={inventory} 
                setInventory={setInventory} 
                labourers={labourers} 
                setLabourers={setLabourers}
                tasks={tasks}
                setTasks={setTasks}
                user={user}
                setUser={setUser}
                appSettings={appSettings}
                setAppSettings={setAppSettings}
                transactions={transactions}
                setTransactions={setTransactions}
                customers={customers}
                setCustomers={setCustomers}
                siteSettlements={siteSettlements}
                setSiteSettlements={setSiteSettlements}
              />
            </TabsContent>
            
            <TabsContent value="inventory" className="mt-0 focus-visible:outline-none">
              <Inventory inventory={inventory} setInventory={setInventory} />
            </TabsContent>

            <TabsContent value="labour" className="mt-0 focus-visible:outline-none">
              <LabourManagement labourers={labourers} setLabourers={setLabourers} tasks={tasks} />
            </TabsContent>
          </div>
        </Tabs>
      </main>

      {/* Footer Bar */}
      <footer className="h-10 border-t border-white/5 bg-[#050505] flex items-center justify-between px-8 text-[9px] uppercase tracking-[0.3em] text-slate-600">
        <span>VoltSync Node 0048-A // East Coast Hub</span>
        <div className="flex gap-6">
          <span>Session: 4.2h</span>
          <span>DB Latency: 12ms</span>
          <span className="text-slate-400">© 2024 VoltSync Indust.</span>
        </div>
      </footer>
    </div>
  );
}


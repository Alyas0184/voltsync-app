/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type StockStatus = 'In Stock' | 'Low Stock' | 'Out of Stock';

export interface InventoryItem {
  id: string;
  name: string;
  category: string;
  quantity: number;
  unit: string;
  minStock: number;
  unitPrice: number;
  discount: number;
  paidAmount: number;
  lastRestocked: string;
}

export type LabourStatus = 'Available' | 'On Assignment' | 'Away';

export interface Labourer {
  id: string;
  name: string;
  role: string;
  status: LabourStatus;
  skills: string[];
  currentTaskId?: string;
  hourlyRate: number;
  yearsOfExperience: number;
  workSite?: string;
  progress?: number;
  contractorPaidAmount?: number;
  contractorPaymentMethod?: PaymentMethod;
}

export interface UserProfile {
  name: string;
  role: string;
  avatar?: string;
}

export type ThemeType = 'monochrome' | 'technical' | 'industrial' | 'classic';
export type AppBackground = 'default' | 'golden' | 'black' | 'white' | 'chocolate' | 'lightgreen' | 'premiumgold';

export interface Customer {
  id: string;
  name: string;
  phone?: string;
  email?: string;
  address?: string;
  totalSpent: number;
  lastVisit: string;
}

export type PaymentStatus = 'Paid' | 'Unpaid' | 'Partial';
export type PaymentMethod = 'Cash' | 'Online' | 'N/A';

export interface SaleTransaction {
  id: string;
  timestamp: string;
  itemId?: string;
  itemName: string;
  quantity: number;
  totalAmount: number;
  paidAmount: number;
  paymentStatus: PaymentStatus;
  paymentMethod: PaymentMethod;
  customerName?: string;
}

export interface AppSettings {
  theme: ThemeType;
  background: AppBackground;
  currency: string;
  notifications: boolean;
}

export interface SiteSettlement {
  siteName: string;
  totalContractValue: number;
  settledAmount: number;
  status: 'Open' | 'Settled';
  lastUpdated: string;
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'error';
  timestamp: string;
  read: boolean;
}

export type TaskStatus = 'Pending' | 'In Progress' | 'Completed' | 'Delayed';

export interface WorkTask {
  id: string;
  title: string;
  description: string;
  status: TaskStatus;
  assignedLabourerId?: string;
  priority: 'Low' | 'Medium' | 'High' | 'Urgent';
  dueDate: string;
  requiredParts: { itemId: string; quantity: number }[];
}

export interface ForecastData {
  itemId: string;
  itemName: string;
  predictedDemand: number;
  confidence: number;
  reasoning: string;
  suggestedReorderDate: string;
}

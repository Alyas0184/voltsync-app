/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { InventoryItem, Labourer, WorkTask } from './types';

export const INITIAL_INVENTORY: InventoryItem[] = [
  {
    id: '1',
    name: '16A Single Pole MCB',
    category: 'Switchgear',
    quantity: 45,
    unit: 'pcs',
    minStock: 20,
    unitPrice: 4.5,
    discount: 0.5,
    paidAmount: 180.0,
    lastRestocked: '2024-03-20',
  },
  {
    id: '2',
    name: '2.5mm² Copper Wire (100m)',
    category: 'Cables',
    quantity: 8,
    unit: 'rolls',
    minStock: 10,
    unitPrice: 85.0,
    discount: 5.0,
    paidAmount: 640.0,
    lastRestocked: '2024-03-15',
  },
  {
    id: '3',
    name: 'LED Batten 4ft 20W',
    category: 'Lighting',
    quantity: 120,
    unit: 'pcs',
    minStock: 30,
    unitPrice: 12.0,
    discount: 1.0,
    paidAmount: 1320.0,
    lastRestocked: '2024-03-25',
  },
  {
    id: '4',
    name: 'Standard Wall Socket (White)',
    category: 'Accessories',
    quantity: 65,
    unit: 'pcs',
    minStock: 50,
    unitPrice: 3.2,
    discount: 0.2,
    paidAmount: 195.0,
    lastRestocked: '2024-03-28',
  }
];

export const INITIAL_LABOUR: Labourer[] = [
  {
    id: 'L1',
    name: 'Alex Rivera',
    role: 'Senior Electrician',
    status: 'On Assignment',
    skills: ['Industrial Wiring', 'Solar Installation'],
    hourlyRate: 450,
    yearsOfExperience: 12,
    workSite: 'METRO STATION A',
    progress: 45,
    contractorPaidAmount: 12500,
    contractorPaymentMethod: 'Online'
  },
  {
    id: 'L2',
    name: 'Sarah Chen',
    role: 'Junior Estimator',
    status: 'On Assignment',
    skills: ['Residential Planning', 'AutoCAD'],
    hourlyRate: 300,
    yearsOfExperience: 3,
    workSite: 'GREEN VALLEY RESIDENCY',
    progress: 75,
    contractorPaidAmount: 8000,
    contractorPaymentMethod: 'Cash'
  },
  {
    id: 'L3',
    name: 'Marcus Thorne',
    role: 'Apprentice',
    status: 'Available',
    skills: ['Conduit Fitting', 'Safety Testing'],
    hourlyRate: 200,
    yearsOfExperience: 1,
    workSite: 'METRO STATION A',
    progress: 20,
    contractorPaidAmount: 3500,
    contractorPaymentMethod: 'Cash'
  }
];

export const INITIAL_TASKS: WorkTask[] = [
  {
    id: 'T1',
    title: 'Hospital Ward Rewiring',
    description: 'Complete replacement of circuits in Ward 4B.',
    status: 'In Progress',
    assignedLabourerId: 'L1',
    priority: 'Urgent',
    dueDate: '2024-04-15',
    requiredParts: [{ itemId: '2', quantity: 2 }],
  }
];
